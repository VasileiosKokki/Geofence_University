1) Δημιουργούμε νέο empty views activity. Language: Java | Minimum SDK: API 30 | Build configuration language: Groovy DSL
2) Κάνουμε δεξί κλικ στον φάκελο app και στο new επιλέγουμε google και google maps views activity
3) Αντιγράφουμε την main του repo στην main του project μας
4) Κάνουμε refactor τον φάκελο gr.hua.dit.android.ergasiait2021042 και αντικαθιστούμε το ergasiait2021042 με το όνομα του project μας
5) Στα local properties κάτω από το sdk.dir=... βάζουμε MAPS_API_KEY=... (με το key μας)
6) Στο build.gradle (Module) αλλάζουμε το compileSdk από 33 σε 34 
7) Στο res/values/strings.xml αλλάζουμε το string name για το app_name από ErgasiaIt2021042 στο όνομα του project μας



Αυτά τα ολίγα, ο μπλε κύκλος είναι ο πιο κοντινός κύκλος σε σχέση με την τρέχουσα τοποθεσία
