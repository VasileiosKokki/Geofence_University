package gr.hua.dit.android.ergasiait2021042;

public class Point {

    public Integer sessionId;

    public String type;

    public Double longitude;

    public Double latitude;

}
